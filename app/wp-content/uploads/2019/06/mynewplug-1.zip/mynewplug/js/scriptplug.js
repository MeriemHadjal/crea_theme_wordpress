var cities = document.querySelector('#ville');
document.querySelector('#ville').addEventListener('keydown',function(saisie){
    console.log('lol');
})