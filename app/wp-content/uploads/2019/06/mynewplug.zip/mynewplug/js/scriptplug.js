var cities = document.querySelector('#ville');
console.log('hello');
function saisie(){
    console.log('lol');
    if(!cities.value == 1){
        return false ;
    }else{
        return true;
    }
}


fetch('https://vicopo.selfbuild.fr/ville').then(function(response){
    return response.json()
}).then(function(response){
    if (cities.length >0){
        console.log('lo');
    }
})